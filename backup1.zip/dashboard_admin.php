<?php
include 'conexao.php';
session_start();

// Verificar se o administrador está logado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit();
}

// Buscar todos os colaboradores
$sql = "SELECT * FROM colaboradores";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Painel do Administrador</title>
</head>
<body>
    <h2>Painel de Administração</h2>
    <a href="logout.php">Logout</a>
    <br><br>
    <h3>Lista de Colaboradores</h3>
    <table border="1">
        <tr>
            <th>Nome</th>
            <th>CPF</th>
            <th>Função</th>
            <th>Celular</th>
            <th>Ações</th>
        </tr>
        <?php while ($colaborador = $resultado->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $colaborador['nome']; ?></td>
            <td><?php echo $colaborador['cpf']; ?></td>
            <td><?php echo $colaborador['funcao']; ?></td>
            <td><?php echo $colaborador['celular']; ?></td>
            <td>
                <a href="detalhes_colaborador.php?id=<?php echo $colaborador['id']; ?>">Ver Detalhes</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
