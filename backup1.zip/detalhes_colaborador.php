<?php
include 'conexao.php';
session_start();

// Verificar se o administrador está logado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit();
}

$colaborador_id = $_GET['id'];

// Buscar dados do colaborador
$sql_colaborador = "SELECT * FROM colaboradores WHERE id = $colaborador_id";
$colaborador = $conn->query($sql_colaborador)->fetch_assoc();

// Buscar registros de ponto do colaborador
$sql_pontos = "SELECT * FROM pontos WHERE colaborador_id = $colaborador_id ORDER BY data DESC";
$pontos = $conn->query($sql_pontos);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Colaborador</title>
</head>
<body>
    <h2>Detalhes do Colaborador</h2>
    <p><strong>Nome:</strong> <?php echo $colaborador['nome']; ?></p>
    <p><strong>CPF:</strong> <?php echo $colaborador['cpf']; ?></p>
    <p><strong>Função:</strong> <?php echo $colaborador['funcao']; ?></p>

    <h3>Registros de Ponto</h3>
    <table border="1">
        <tr>
            <th>Data</th>
            <th>Início</th>
            <th>Saída Almoço</th>
            <th>Retorno Almoço</th>
            <th>Fim</th>
            <th>Ações</th>
        </tr>
        <?php while ($ponto = $pontos->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $ponto['data']; ?></td>
            <td><?php echo $ponto['inicio_jornada']; ?></td>
            <td><?php echo $ponto['saida_almoco']; ?></td>
            <td><?php echo $ponto['retorno_almoco']; ?></td>
            <td><?php echo $ponto['fim_jornada']; ?></td>
            <td>
                <a href="corrigir_ponto.php?ponto_id=<?php echo $ponto['id']; ?>">Corrigir</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
