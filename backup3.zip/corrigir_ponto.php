<?php
include 'conexao.php';
session_start();

// Verificar se o administrador está logado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit();
}

// Obter o ID do ponto a ser corrigido
$ponto_id = $_GET['ponto_id'];

// Buscar os dados do ponto selecionado
$sql = "SELECT p.*, c.nome FROM pontos p 
        JOIN colaboradores c ON p.colaborador_id = c.id 
        WHERE p.id = $ponto_id";
$resultado = $conn->query($sql);
$ponto = $resultado->fetch_assoc();

// Atualizar o registro de ponto
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $inicio_jornada = $_POST['inicio_jornada'];
    $saida_almoco = $_POST['saida_almoco'];
    $retorno_almoco = $_POST['retorno_almoco'];
    $fim_jornada = $_POST['fim_jornada'];
    $justificativa = $_POST['justificativa'];

    // Atualizar no banco de dados
    $sql_update = "UPDATE pontos SET 
                    inicio_jornada = '$inicio_jornada',
                    saida_almoco = '$saida_almoco',
                    retorno_almoco = '$retorno_almoco',
                    fim_jornada = '$fim_jornada',
                    justificativa = '$justificativa'
                  WHERE id = $ponto_id";
    $conn->query($sql_update);

    echo "<p style='color: green;'>Ponto atualizado com sucesso!</p>";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Correção de Ponto</title>
</head>
<body>
    <h2>Correção de Ponto para <?php echo $ponto['nome']; ?></h2>

    <form method="POST">
        <label>Início da Jornada:</label><br>
        <input type="time" name="inicio_jornada" value="<?php echo $ponto['inicio_jornada']; ?>" required><br><br>

        <label>Saída para Almoço:</label><br>
        <input type="time" name="saida_almoco" value="<?php echo $ponto['saida_almoco']; ?>"><br><br>

        <label>Retorno do Almoço:</label><br>
        <input type="time" name="retorno_almoco" value="<?php echo $ponto['retorno_almoco']; ?>"><br><br>

        <label>Fim da Jornada:</label><br>
        <input type="time" name="fim_jornada" value="<?php echo $ponto['fim_jornada']; ?>" required><br><br>

        <label>Justificativa:</label><br>
        <textarea name="justificativa" rows="4" cols="50"><?php echo $ponto['justificativa']; ?></textarea><br><br>

        <button type="submit">Atualizar Ponto</button>
    </form>
    <br>
    <a href="dashboard_admin.php">Voltar ao Painel</a>
</body>
</html>
